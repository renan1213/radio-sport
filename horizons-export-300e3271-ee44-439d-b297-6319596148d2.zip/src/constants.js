export const API_KEY = 'c296fb39fdab402c80aaab8da61a8638';
export const INSTAGRAM_USERNAME = 'pedroregisalenda';
export const FACEBOOK_USERNAME = 'pedroregisalenda';
export const PHONE_NUMBER = '5588992557103';
